# Organizational chart with D3.js, expandable, zoomable, and fully initialized

An organizational chart made with D3.js with lots of features such as expanding and zooming.

Read the [full article](https://onyxdev.net/snippets-item/organizational-chart-with-d3-js-expandable-zoomable-and-fully-initialized/) on [**Onyxdev**](https://onyxdev.net/)

## Credits

[D3.js](https://d3js.org/)<br />
[Source Sans Pro font](https://fonts.google.com/specimen/Source+Sans+Pro)<br />
[Original code by Julien Henri Reszka](https://observablehq.com/@julienreszka/d3-v5-org-chart)

## `Stay safe 😷`
